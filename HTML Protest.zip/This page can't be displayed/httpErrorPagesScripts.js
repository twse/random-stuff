
function isExternalUrlSafeForNavigation(urlStr)
{
var regEx = new RegExp("^(http(s?)|ftp|file)://", "i");
return regEx.exec(urlStr);
}
function clickRefresh()
{
var location = window.location.href;
var poundIndex = location.indexOf('#');
if (poundIndex != -1 && poundIndex+1 < location.length && isExternalUrlSafeForNavigation(location.substring(poundIndex+1)))
{
window.location.replace(location.substring(poundIndex+1));
}
}
function navCancelInit()
{
var location = window.location.href;
var poundIndex = location.indexOf('#');
if (poundIndex != -1 && poundIndex+1 < location.length && isExternalUrlSafeForNavigation(location.substring(poundIndex+1)))
{
var bElement = document.createElement("A");
bElement.innerText = L_REFRESH_TEXT;
bElement.href = 'javascript:clickRefresh()';
navCancelContainer.appendChild(bElement);
}
else
{
var textNode = document.createTextNode(L_RELOAD_TEXT);
navCancelContainer.appendChild(textNode);
}
}
function expandCollapse(elem, changeImage)
{
if (document.getElementById)
{
ecBlock = document.getElementById(elem);
if (ecBlock != undefined && ecBlock != null)
{
if (changeImage)
{
elemImage = document.getElementById(elem + "Image");
}
if (!changeImage || (elemImage != undefined && elemImage != null))
{
if (ecBlock.currentStyle.display == "none" || ecBlock.currentStyle.display == null || ecBlock.currentStyle.display == "")
{
ecBlock.style.display = "block";
if (changeImage)
{
elemImage.src = "up.png";
}
}
else if (ecBlock.currentStyle.display == "block")
{
ecBlock.style.display = "none";
if (changeImage)
{
elemImage.src = "down.png";
}
}
else
{
ecBlock.style.display = "block";
if (changeImage)
{
elemImage.src = "up.png";
}
}
}
}
}
}
function initHomepage()
{
DocURL=document.location.href;
var poundIndex = DocURL.indexOf('#');
if (poundIndex != -1 && poundIndex+1 < location.length && isExternalUrlSafeForNavigation(location.substring(poundIndex+1)))
{
protocolIndex=DocURL.indexOf("://", 4);
serverIndex=DocURL.indexOf("/", protocolIndex + 3);
BeginURL=DocURL.indexOf("#",1) + 1;
urlresult=DocURL.substring(BeginURL, serverIndex);
if (protocolIndex - BeginURL > 7)
urlresult="";
displayresult=DocURL.substring(protocolIndex + 3, serverIndex);
}
else
{
displayresult = "";
urlresult = "";
}
var aElement = document.createElement("A");
aElement.innerText = displayresult;
aElement.href = urlresult;
homepageContainer.appendChild(aElement);
}
function initConnectionStatus()
{
if (navigator.onLine)
{
checkConnection.innerText = L_CONNECTION_ON_TEXT;
}
else
{
checkConnection.innerText = L_CONNECTION_OFF_TEXT;
}
}
function initGoBack()
{
if (history.length < 1)
{
var textNode = document.createTextNode(L_GOBACK_TEXT);
goBackContainer.appendChild(textNode);
}
else
{
var bElement = document.createElement("A");
bElement.innerText = L_GOBACK_TEXT ;
bElement.href = "javascript:history.back();";
goBackContainer.appendChild(bElement);
}
}
function initMoreInfo(infoBlockID)
{
var bElement = document.createElement("A");
bElement.innerText = L_MOREINFO_TEXT;
bElement.href = "javascript:expandCollapse(\'infoBlockID\', true);";
moreInfoContainer.appendChild(bElement);
}
function initOfflineUser(offlineUserID)
{
var bElement = document.createElement("A");
bElement.innerText = L_OFFLINE_USERS_TEXT;
bElement.href = "javascript:expandCollapse('offlineUserID', true);";
offlineUserContainer.appendChild(bElement);
}
function initUnframeContent()
{
var location = window.location.href;
var poundIndex = location.indexOf('#');
if (poundIndex != -1 && poundIndex+1 < location.length && isExternalUrlSafeForNavigation(location.substring(poundIndex+1)))
{
document.getElementById("whatToDoIntro").style.display="";
document.getElementById("whatToDoBody").style.display="";
}
}
function removeNoScriptElements() {
var noScriptElements = document.getElementsByTagName("noscript");
for (var i = noScriptElements.length - 1; i >= 0; i--)
{
var bElement = noScriptElements[i];
if (bElement !== undefined && bElement !== null)
{
bElement.removeNode(true);
}
}
}
function makeNewWindow()
{
var location = window.location.href;
var poundIndex = location.indexOf('#');
if (poundIndex != -1 && poundIndex+1 < location.length && isExternalUrlSafeForNavigation(location.substring(poundIndex+1)))
{
window.open(location.substring(poundIndex+1));
}
}
function setTabInfo(tabInfoBlockID)
{
var bPrevElement = document.getElementById("tabInfoTextID");
var bPrevImage = document.getElementById("tabInfoBlockIDImage");
if (bPrevElement != null)
{
tabInfoContainer.removeChild(bPrevElement);
}
if (bPrevImage != null)
{
tabImageContainer.removeChild(bPrevImage);
}
var bElement = document.createElement("A");
var bImageElement = document.createElement("IMG");
var ecBlock = document.getElementById(tabInfoBlockID);
if ((ecBlock != undefined && ecBlock != null) &&
(ecBlock.currentStyle.display == "none" || ecBlock.currentStyle.display == null || ecBlock.currentStyle.display == ""))
{
bElement.innerText = L_SHOW_HOTKEYS_TEXT;
bImageElement.alt = L_SHOW_HOTKEYS_TEXT;
bImageElement.src="down.png";
}
else
{
bElement.innerText = L_HIDE_HOTKEYS_TEXT;
bImageElement.alt = L_HIDE_HOTKEYS_TEXT;
bImageElement.src="up.png";
}
bElement.id = "tabInfoTextID";
bElement.href = "javascript:expandCollapse(\'tabInfoBlockID\', false); setTabInfo('tabInfoBlockID');";
bImageElement.id="tabInfoBlockIDImage";
bImageElement.border="0";
bImageElement.className="actionIcon";
tabInfoContainer.appendChild(bElement);
tabImageContainer.appendChild(bImageElement);
}
function launchInternetOptions()
{
window.external.msLaunchInternetOptions();
}
function diagnoseConnection()
{
window.external.DiagnoseConnection();
}
function diagnoseConnectionAndRefresh()
{
window.external.DiagnoseConnection();
if (navigator.onLine)
{
clickRefresh();
}
}
function addURL()
{
var urlResult = "";
var DocURL = document.location.href;
var urlPlaceholder = document.getElementById("webpage");
var beginIndex = DocURL.indexOf('#') + 1;
if (DocURL.indexOf("file://", beginIndex) == -1)
{
var protocolEndIndex = DocURL.indexOf("://", beginIndex);
var endIndex=DocURL.indexOf("/", protocolEndIndex + 3);
urlResult = DocURL.substring(beginIndex, endIndex);
}
urlPlaceholder.innerText = urlResult + " ";
}
function addDomainName()
{
var domainNamePlaceholder = document.getElementById("DomainName");
domainNamePlaceholder.innerText = findValue("DomainName=") + " ";
}
function addProxyDetail()
{
var proxyDetailPlaceholder = document.getElementById("ProxyDetail");
proxyDetailPlaceholder.innerText = findValue("ProxyDetail=");
}
function findValue(key)
{
var value = '';
DocQuery = document.location.search;
BeginString = DocQuery.indexOf(key);
if (BeginString > 0)
{
BeginString += key.length;
EndString = Math.max(0, Math.min(DocQuery.indexOf("&", BeginString), DocQuery.indexOf("#", BeginString)));
if (EndString > 0)
{
value = DocQuery.substring(BeginString, EndString);
}
else
{
value = DocQuery.substring(BeginString);
}
}
return value;
}
